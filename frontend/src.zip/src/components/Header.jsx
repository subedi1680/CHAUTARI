// eslint-disable-next-line no-unused-vars
import React from "react";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";

const Header = () => {
  const location = useLocation();
  const path = location.pathname;

  // Determine what to show based on the path
  const isLoginPage = path = ["/","/login"];
  const isRegisterPage = path === "/register";
  const isHomePage = ["/home", "/create-post", "/user-settings"].includes(path);
  // eslint-disable-next-line no-unused-vars
  const isForgotPassword = path === "/forgot-password";

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <div className="container-fluid">
        {/* Logo */}
        <Link className="navbar-brand fw-bold text-dark" to="/">
          CHAUTARI
        </Link>

        {/* Search Bar (Hidden on Login and Register Pages) */}
        {!isLoginPage && !isRegisterPage && (
          <form className="d-flex mx-auto" style={{ width: "40%" }}>
            <input className="form-control me-2" type="search" placeholder="Search" />
          </form>
        )}

        {/* Right Side */}
        <div>
          {isHomePage ? (
            // Show user settings and notifications on home-like pages
            <>
              <Link to="/notifications" className="btn btn-outline-primary me-2">Notifications</Link>
              <Link to="/user-settings" className="btn btn-outline-secondary">User Settings</Link>
            </>
          ) : isLoginPage ? (
            // Hide login button on login page
            null
          ) : isRegisterPage ? (
            // Hide sign-up button on register page
            null
          ) : (
            // Default login and signup buttons
            <>
              <Link to="/login" className="btn btn-outline-primary me-2">Login</Link>
              <Link to="/register" className="btn btn-outline-secondary">Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Header;
